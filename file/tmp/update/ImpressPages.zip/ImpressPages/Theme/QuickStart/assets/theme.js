//this is just an example how to add JavaScript to your theme
