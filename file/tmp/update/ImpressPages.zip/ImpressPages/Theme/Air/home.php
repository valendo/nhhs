<?php echo ipView('_header.php')->render(); ?>
    <div class="main col_12">
        <?php echo ipBlock('main')->exampleContent(' '); ?>
    </div>
    <div class="clear"></div>
<?php echo ipView('_footer.php')->render(); ?>
