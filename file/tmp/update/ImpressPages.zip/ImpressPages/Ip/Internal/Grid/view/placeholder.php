<div class="ipModuleGrid ipsGrid" data-gateway="<?php echo escAttr($gateway); ?>"></div>
