<?php
/**
 * @package   ImpressPages
 */

namespace Ip\Internal\Grid;


abstract class Model
{

    public abstract function handleMethod();


}
