<?php
/**
 * @package ImpressPages
 *
 *
 */


namespace Ip\Internal\Dispatcher;

/**
 * Slot dispatcher class
 *
 */
class SlotDispatcher extends JobDispatcher
{
}
