<div class="ip">
    <div class="ipAdminWidgetToolbar hidden" id="ipWidgetHeadingControls">
        <div class="btn-toolbar" role="toolbar">
            <div class="btn-group">
                <button type="button" data-level="1" class="btn btn-controls ipsH"><?php _e('H1', 'Ip-admin'); ?></button>
                <button type="button" data-level="2" class="btn btn-controls ipsH"><?php _e('H2', 'Ip-admin'); ?></button>
                <button type="button" data-level="3" class="btn btn-controls ipsH"><?php _e('H3', 'Ip-admin'); ?></button>
                <button type="button" class="btn btn-controls ipsOptions"><?php _e('Options', 'Ip-admin'); ?></button>
            </div>
        </div>
    </div>
</div>
