<div class="ip">
    <div id="ipWidgetLayoutPopup" class="modal fade">
        <a class="ipsItemTemplate hidden list-group-item" href="#"></a>
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title"><?php _e('Choose widget skin', 'Ip-admin'); ?></h4>
                </div>
                <div class="modal-body">
                    <ul class="ipsList list-group"></ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php _e('Cancel', 'Ip-admin'); ?></button>
                </div>
            </div>
        </div>
    </div>
</div>
