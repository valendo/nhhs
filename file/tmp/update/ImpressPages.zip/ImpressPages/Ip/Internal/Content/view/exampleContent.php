<?php
/**
 * This comment block is used just to make IDE suggestions to work
 * @var $this \Ip\View
 */
?>
<?php echo ipRenderWidget('Heading', array('title' => __('Drag & drop here', 'Ip-admin', false))); ?>

<?php echo ipRenderWidget('Text', array('text' => '
    <p>'.__('Add widgets from the top menu by dragging and dropping.', 'Ip-admin', false).'</p>
')); ?>
